Personal Portfolio of #Juan Cabrera

This is a web portfolio created with HTML and CSS. It is designed to showcase my skills and knowledge acquired during my training at Riwi and as a freelancer.

#Description

This website includes several key sections:

About Me: Here is a brief description of me, showing everything in my own words. Portfolio: Here I showcase my skills, abilities, and a few of my projects. Contact: Here you can contact me by sending me an email so I can hire you.

#TechnologiesUsed HTML CSS (with responsive design and interactive effects) Google Fonts ('Crimson Text', serif) Grid Layout Flex Box Media Queries

#HowToView You can open the index.html file in any modern browser.

Clone this repository or download the ZIP file. Open index.html in your browser.